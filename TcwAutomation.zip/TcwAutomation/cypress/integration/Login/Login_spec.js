//<reference types="Cypress"/>
import LoginPage from '../../support/pageObjects/LoginPage'
describe('To Verify Login Screen', function() 
{
    it('SuccessLogin', function() {
        const loginPage=new LoginPage()
        cy.visit("https://web.connect.trimble.com/")
        loginPage.enterUserName()
        loginPage.enterPassword()
        loginPage.clickSignIn()                     
    })   
})
