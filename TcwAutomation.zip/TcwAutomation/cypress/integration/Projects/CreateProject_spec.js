//<reference types="Cypress"/>
describe('Project creation validation', function()
{
it('To create New Projects and verifying the same', function()
{
cy.visit("https://web.connect.trimble.com/#/projects")



})

})

