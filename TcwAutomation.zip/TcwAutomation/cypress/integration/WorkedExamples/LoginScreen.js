context('Cypress Demo',() => {
    it('login scenario',() => {
    cy.visit('http://automationpractice.com/index.php')
    cy.get('.login').click()
    cy.get('#email').type('vijayamirtharajkp@gmail.com')
    cy.get('#passwd').type('12345')
    cy.get('#SubmitLogin > span').click()
    cy.title().should('include','My account - My Store')
    })

    it('Dress Purchase',() => {
    cy.get('#search_query_top').type('Printed Chiffon Dress')
    cy.get('#searchbox > .btn').click()
    cy.scrollTo('right')
    cy.scrollTo('top')
    cy.get('.first-in-line > .product-container > .right-block > h5 > .product-name').should('include','Printed Chiffon Dress')
     



    })
})

