/// <reference types="Cypress" />

describe('My Second Test Suite', function () {
    before(function () {
        // runs once before all tests in the block
        cy.fixture('example').then(function (data) {
        this.data=data
        }

        )

    })

    it('My FirstTest case', function () {

        cy.visit('https://rahulshettyacademy.com/angularpractice/#/')
        cy.get('input[name="name"]:nth-child(2)').type(this.data.name)
        cy.get(':nth-child(2) > .form-control').type(this.data.email)
        cy.get('#exampleInputPassword1').type(this.data.password)
        cy.get('#exampleCheck1').check()
        cy.get('select').select(this.data.gender)
        cy.get('#inlineRadio2').check()
        cy.get(':nth-child(8) > .form-control').type(this.data.date)
        cy.get('.btn').click()
        cy.scrollTo("topRight")
        //cy.get('.alert > alert-success > alert-dismissible').should('have.value','Success! The Form has been submitted successfully!.')
        cy.get('.alert > strong').contains('Success!')
        //cy.get('strong').should('have.value',this.data.alertmessage)
        cy.get(':nth-child(4) > .ng-untouched').should('have.value',this.data.name)
        cy.get('input[name="name"]:nth-child(2)').should('have.attr','minlenght','2')
        cy.get('#inlineRadio3').should('be.disabled')

    })
    })  
