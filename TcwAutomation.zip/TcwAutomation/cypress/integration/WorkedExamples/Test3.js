/// <reference types="Cypress" />
describe('Adding Cart',function()
{
    it('Launching App',function()
    {
    cy.visit('https://react-shopping-cart-67954.firebaseapp.com/')
    }
    )
    it('Choosing Product',function()
    {
    cy.wait(5000)    
    cy.scrollTo("center") 
    //cy.get('.div:nth-child(2) main:nth-child(2) div.shelf-container div.shelf-item:nth-child(3) > div.shelf-item__buy-btn').click()
    cy.get('[data-sku="51498472915966370"] > .shelf-item__buy-btn').click()
    }
    )
    it('Checkout Product',function()
        {
    cy.wait(4000)
    cy.get('div:nth-child(2) div.float-cart.float-cart--open:nth-child(3) div.float-cart__content div.float-cart__footer > div.buy-btn').click()
    
        }
    )
   

    })
