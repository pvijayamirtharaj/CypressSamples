describe('My Second Test Suite', function () {
    it('My FirstTest case', function () {

        cy.visit('https://web.connect.trimble.com/')
        cy.xpath("//input[@id='user']").type('vijay_amirtharaj@trimble.com')
        cy.xpath("//input[@id='password']").type('Spime@123')
        cy.xpath("//button[@id='signin']").click()
        

            
        

    })
})