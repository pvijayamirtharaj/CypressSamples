class LoginPage
{
    
    enterUserName()
    {
        return  cy.xpath("//input[@id='user']").type('vijay_amirtharaj@trimble.com')
        
    }
    enterPassword()
    {
        return cy.xpath("//input[@id='password']").type('Spime@123')
    }
    clickSignIn()
    {
        return cy.xpath("//button[@id='signin']").click()

    }
    
}
export  default LoginPage;