class ProjectPage
{
    clickNewProject()
    {
        return cy.xpath("//span[@class='ng-binding']").click()
    }
    enterProjectName()
    {
        return cy.xpath("//input[@id='name']").type("TestAutomation")
    }
    uploadProjectImage()
    {
        return cy.xpath("//i[@class='icon-browse']").click()

    }
    chooseProjectLocation()
    {
        return cy.xpath("//select[@id='podLocation']").select('NorthAmerica')
    }
    clickProjectMoreOptions()
    {
        return cy.xpath("//span[contains(text(),'More options')]").click()
    }
    enterProjectDescription()
    {
        return cy.xpath("//textarea[@id='description']").type("Sample Project")
    }
    chooseProjectStartDate()
    {
        return cy.xpath("//div[10]//div[1]//span[1]//div[1]//span[1]//button[1]//i[1]").click()
        return cy.xpath("//span[contains(text(),'12')]").click()

    }
    chooseProjectEndDate()
    {
        return cy.xpath("//div[11]//div[1]//span[1]//div[1]//span[1]//button[1]//i[1]").click()
        return cy.xpath("//span[@class='ng-binding'][contains(text(),'26')]").click()

    }
    clickProjectSubmit()
    {
        return cy.xpath("//span[contains(text(),'Submit')]").click()
    }
}
export default ProjectPage;